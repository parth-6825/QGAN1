# Novel protein sequence generation using Quantum GANs

The aim of the project is to generate novel protein sequences using Quantum GANs. Details about the model, datasets used, references and other sources are mentioned in detail in the presentation [final_submission.pptx](final_submission.pptx)

