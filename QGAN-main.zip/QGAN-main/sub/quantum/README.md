# Generator Quantum Circuit

<img src='qcircuit.png'>

# Results and Output

```
Generated sequences = gen_seq.csv
```
