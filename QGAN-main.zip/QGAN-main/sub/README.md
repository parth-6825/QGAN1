# Datasets
```
dataset                      - train_sequences.csv
processed data for quantum   - penultimate.csv
processed data for classical - ultimate.csv
```
# Results and Comparison
```
generator_loss       (quantum)  = 0.651
discriminator_loss   (quantum)  = 1.217
generator_loss     (classical)  = 1.216
discriminator_loss (classical)  = 0.201
```
